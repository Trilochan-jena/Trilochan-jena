import './App.css';
import { BrowserRouter, Routes } from 'react-router-dom';
import Navbar from './componete/navbar';
import Sidebar from './componete/sidebar';
import Postbar from './componete/postbar';
import Rightbar from './componete/rightbar';
import { data } from './data';
import { data2 } from './data';
import { useEffect, useState } from 'react';
function App() {
  const [toggle, setToggle] = useState(true)
  const [bgColor, setBgcolor] = useState("#232D35")
  const [color, setColor] = useState("white")

  function getToggle() {
    setToggle(!toggle)
    if (toggle) {
      setBgcolor("rgb(255,255,255)");
      setColor("black");
      document.querySelector("body").style.backgroundColor = "cbc5c5";
    } else {
      setBgcolor("#232D35");
      setColor("white");
      document.querySelector("body").style.backgroundColor = "black";

    }

  }

  return (


    <>
      <Navbar
        bgColor={bgColor} color={color} getToggle={getToggle} toggle={toggle}
      />

      <div className='Container'>
        <div className='side_bar'>
          <Sidebar bgColor={bgColor} color={color} />

        </div>
        <div className='post_bar'>

          {data.map((e) => (
            <Postbar key={e.id} data={e} bgColor={bgColor} color={color} />
          ))}

        </div>
        <div className='right_bar'>
          {data2.map((e) => (
            <Rightbar key={e.id} data2={e} bgColor={bgColor} color={color} />
          ))}

        </div>
      </div>


    </>
  );
}

export default App;
