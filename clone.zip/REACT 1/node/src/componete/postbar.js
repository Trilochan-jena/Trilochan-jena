import React from 'react'
import img1 from "../assets/pexels-pixabay-533769.jpg";
import { BsThreeDotsVertical } from "react-icons/bs";
import { FaHeart } from "react-icons/fa6";
import { FaComment } from "react-icons/fa";
import { FaShare } from "react-icons/fa";

const Postbar = ({ data,bgColor, color}) => {
    return (
        <>
            <div className='post_contain'style={{
                backgroundColor:`${bgColor}`,
                color:`${color}`
            }}>
                <div className='person'>
                    <div className='author'>
                        <div className='img'><img src={data.pImg} alt='' ></img></div>
                        <div className='text'>
                            <h4 >{data.userName}</h4>
                            <p>{data.title}</p>
                        </div>
                    </div>
                    <div className='dot'><BsThreeDotsVertical /></div>

                </div>
                <p>{data.description}</p>
                <div className='pot_img'>
                    <img src={data.mImg}></img>
                </div>

                <div className='like_cmt'>
                    <div className='like'><FaHeart className='item' />{data.comment}</div>
                    <div className='cmt'><FaComment className='item' />{data.comment}</div>
                    <div className='share'><FaShare className='item' />{data.share}</div>
                </div>
            </div>
        </>
    )
}

export default Postbar