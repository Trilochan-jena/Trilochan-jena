import React from 'react'
import { FcSearch } from "react-icons/fc";
import { IoFilterSharp } from "react-icons/io5";
import { BsToggle2On } from "react-icons/bs";
import { BsToggle2Off } from "react-icons/bs";
const Navbar = ({ bgColor, color, getToggle,toggle }) => {
  return (
    <div>
      <div className='nav_bar'>
        <div className='logo' style={{
          backgroundColor: `${bgColor}`,
          color: `${color}`,
        }}>WDM
          <div onClick={getToggle}>{toggle? (<BsToggle2On />) : (<BsToggle2Off />)}</div>
        </div>
        <div className='search' style={{
          backgroundColor: `${bgColor}`,
          color: `${color}`,
        }}>
          <div className='left' ><FcSearch  style={{marginRight:"15px", }}/>Search Here</div>
          <div className='right'> <IoFilterSharp />filters</div>

        </div>
        <div className='seller' style={{
          backgroundColor: `${bgColor}`,
          color: `${color}`,
        }}>Become a seller</div>
      </div>
    </div>
  )
}

export default Navbar