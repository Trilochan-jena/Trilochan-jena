import React from 'react'
import { FaHome } from "react-icons/fa";
import { IoIosNotifications } from "react-icons/io";
import { BiConversation } from "react-icons/bi";
import { FaCartShopping } from "react-icons/fa6";
import { FaWallet } from "react-icons/fa";
import { GrUserManager } from "react-icons/gr";
import { IoIosLogOut } from "react-icons/io";

const Sidebar = ({bgColor,color}) => {
    return (
        <>
            <div className='side_bar_contain' style={{
                backgroundColor:`${bgColor}`,
                color:`${color}`
            }}>
                <div className='top_contain'>
                    <div className='items'><FaHome className='icons' />HOME</div>
                    <div className='items'><IoIosNotifications className='icons'/>NOTIFICATION</div>
                    <div className='items'><FaCartShopping className='icons'/>SHOP</div>
                    <div className='items'><BiConversation className='icons '/>CONVERSATION</div>
                    <div className='items'><FaWallet className='icons'/>WALET</div>
                    <div className='items'><GrUserManager className='icons'/>MY PROFILE</div>
                </div>
                <div className='log_out items icons'>
                    <IoIosLogOut />log Out
                </div>
            </div>

        </>
    )
}

export default Sidebar