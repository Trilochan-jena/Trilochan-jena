import React from 'react'
import Main from './main'
import { BrowserRouter, Route, Routes } from 'react-router-dom'

const Routing = () => {
    return (
        <BrowserRouter>
         
            <Routes>
                <Route path='/' element={<Main />} />
            </Routes>
        </BrowserRouter>
    )
}

export default Routing